import styled from "styled-components";

export const InputComponent = styled.input`
  border: none;
  border-radius: 5px;
  box-shadow: 0 0 3px #21212168;
  padding: 5px 10px;
  max-width: 400px;
`;
